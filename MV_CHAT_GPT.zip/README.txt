Como rodar o chatbot:
1. Instale as dependências:
   pip install -r requirements.txt

2. No arquivo 'server.py', coloque sua chave da API OpenRouter no local indicado ('SUA_API_KEY_AQUI').

3. Execute o servidor com:
   python server.py

4. Abra o arquivo 'index.html' em seu navegador para começar a conversar com o bot.

Para hospedar online, siga o tutorial em Render ou Railway.
